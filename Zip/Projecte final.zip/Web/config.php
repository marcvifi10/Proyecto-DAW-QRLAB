<?php

$host = '172.17.100.6';
$user = 'usuari_bd';
$pwd = 'Quimica@2018';
$database = 'qrlab';

$connexio = new mysqli($host,$user,$pwd,$database);
?>
